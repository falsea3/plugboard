--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 17.11
-- Dumped by pg_dump version 17.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE v_src;
--
-- Name: v_src; Type: DATABASE; Schema: -; Owner: relay
--

CREATE DATABASE v_src WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE v_src OWNER TO relay;

\unrestrict (null)
\connect v_src
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: Odd Schema; Type: SCHEMA; Schema: -; Owner: plugboard_owner
--

CREATE SCHEMA "Odd Schema";


ALTER SCHEMA "Odd Schema" OWNER TO plugboard_owner;

--
-- Name: app; Type: SCHEMA; Schema: -; Owner: relay
--

CREATE SCHEMA app;


ALTER SCHEMA app OWNER TO relay;

--
-- Name: SCHEMA app; Type: COMMENT; Schema: -; Owner: relay
--

COMMENT ON SCHEMA app IS 'Application data';


--
-- Name: citext; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS citext WITH SCHEMA public;


--
-- Name: EXTENSION citext; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION citext IS 'data type for case-insensitive character strings';


--
-- Name: email; Type: DOMAIN; Schema: app; Owner: relay
--

CREATE DOMAIN app.email AS text COLLATE pg_catalog."C" NOT NULL DEFAULT 'none@example.com'::text
	CONSTRAINT email_at CHECK ((VALUE ~~ '%@%'::text));


ALTER DOMAIN app.email OWNER TO relay;

--
-- Name: DOMAIN email; Type: COMMENT; Schema: app; Owner: relay
--

COMMENT ON DOMAIN app.email IS 'Has an @';


--
-- Name: CONSTRAINT email_at ON DOMAIN email; Type: COMMENT; Schema: app; Owner: relay
--

COMMENT ON CONSTRAINT email_at ON DOMAIN app.email IS 'Needs an at sign';


--
-- Name: floatrange; Type: TYPE; Schema: app; Owner: relay
--

CREATE TYPE app.floatrange AS RANGE (
    subtype = double precision,
    multirange_type_name = app.floatmultirange,
    subtype_diff = float8mi
);


ALTER TYPE app.floatrange OWNER TO relay;

--
-- Name: mood; Type: TYPE; Schema: app; Owner: plugboard_owner
--

CREATE TYPE app.mood AS ENUM (
    'sad',
    'ok',
    'happy',
    'it''s fine'
);


ALTER TYPE app.mood OWNER TO plugboard_owner;

--
-- Name: TYPE mood; Type: COMMENT; Schema: app; Owner: plugboard_owner
--

COMMENT ON TYPE app.mood IS 'How it went';


--
-- Name: pair; Type: TYPE; Schema: app; Owner: relay
--

CREATE TYPE app.pair AS (
	a integer,
	b text COLLATE pg_catalog."C"
);


ALTER TYPE app.pair OWNER TO relay;

--
-- Name: is_positive(numeric); Type: FUNCTION; Schema: app; Owner: relay
--

CREATE FUNCTION app.is_positive(n numeric) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $$ SELECT n > 0 $$;


ALTER FUNCTION app.is_positive(n numeric) OWNER TO relay;

--
-- Name: positive; Type: DOMAIN; Schema: app; Owner: relay
--

CREATE DOMAIN app.positive AS numeric(12,2)
	CONSTRAINT positive_check CHECK (app.is_positive(VALUE));


ALTER DOMAIN app.positive OWNER TO relay;

--
-- Name: add_int(integer, integer); Type: FUNCTION; Schema: app; Owner: relay
--

CREATE FUNCTION app.add_int(state integer, v integer) RETURNS integer
    LANGUAGE sql IMMUTABLE
    AS $$SELECT state + v$$;


ALTER FUNCTION app.add_int(state integer, v integer) OWNER TO relay;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: orders; Type: TABLE; Schema: app; Owner: relay
--

CREATE TABLE app.orders (
    id bigint NOT NULL,
    customer_id integer NOT NULL,
    total app.positive,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    tags text[] DEFAULT '{}'::text[],
    note text,
    parent_id bigint,
    pair app.pair,
    span app.floatrange,
    during tstzrange
);


ALTER TABLE app.orders OWNER TO relay;

--
-- Name: big_orders; Type: VIEW; Schema: app; Owner: relay
--

CREATE VIEW app.big_orders AS
 SELECT id,
    customer_id,
    total,
    items,
    tags,
    note,
    parent_id,
    pair,
    span,
    during
   FROM app.orders
  WHERE ((total)::numeric > (100)::numeric);


ALTER VIEW app.big_orders OWNER TO relay;

--
-- Name: VIEW big_orders; Type: COMMENT; Schema: app; Owner: relay
--

COMMENT ON VIEW app.big_orders IS 'Over 100';


--
-- Name: big_orders_of(integer); Type: FUNCTION; Schema: app; Owner: relay
--

CREATE FUNCTION app.big_orders_of(cid integer) RETURNS SETOF app.big_orders
    LANGUAGE sql
    AS $$ SELECT * FROM app.big_orders WHERE customer_id = cid $$;


ALTER FUNCTION app.big_orders_of(cid integer) OWNER TO relay;

--
-- Name: next_ticket(); Type: FUNCTION; Schema: app; Owner: relay
--

CREATE FUNCTION app.next_ticket() RETURNS bigint
    LANGUAGE sql
    AS $$ SELECT nextval('app.ticket_seq') $$;


ALTER FUNCTION app.next_ticket() OWNER TO relay;

--
-- Name: order_count(integer); Type: FUNCTION; Schema: app; Owner: relay
--

CREATE FUNCTION app.order_count(cid integer) RETURNS bigint
    LANGUAGE sql STABLE
    BEGIN ATOMIC
 SELECT count(*) AS count
    FROM app.orders
   WHERE (orders.customer_id = order_count.cid);
END;


ALTER FUNCTION app.order_count(cid integer) OWNER TO relay;

--
-- Name: reset_cache(); Type: PROCEDURE; Schema: app; Owner: relay
--

CREATE PROCEDURE app.reset_cache()
    LANGUAGE sql
    AS $$ DELETE FROM app.cache $$;


ALTER PROCEDURE app.reset_cache() OWNER TO relay;

--
-- Name: touch(); Type: FUNCTION; Schema: app; Owner: plugboard_owner
--

CREATE FUNCTION app.touch() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.note := coalesce(NEW.note, 'touched');
  RETURN NEW;
END
$$;


ALTER FUNCTION app.touch() OWNER TO plugboard_owner;

--
-- Name: FUNCTION touch(); Type: COMMENT; Schema: app; Owner: plugboard_owner
--

COMMENT ON FUNCTION app.touch() IS 'Fills note';


--
-- Name: my_sum(integer); Type: AGGREGATE; Schema: app; Owner: relay
--

CREATE AGGREGATE app.my_sum(integer) (
    SFUNC = app.add_int,
    STYPE = integer,
    INITCOND = '0'
);


ALTER AGGREGATE app.my_sum(integer) OWNER TO relay;

--
-- Name: Mixed Case; Type: TABLE; Schema: Odd Schema; Owner: relay
--

CREATE TABLE "Odd Schema"."Mixed Case" (
    "Select" integer,
    "a""b" text
);


ALTER TABLE "Odd Schema"."Mixed Case" OWNER TO relay;

--
-- Name: COLUMN "Mixed Case"."a""b"; Type: COMMENT; Schema: Odd Schema; Owner: relay
--

COMMENT ON COLUMN "Odd Schema"."Mixed Case"."a""b" IS 'odd column';


--
-- Name: a; Type: TABLE; Schema: app; Owner: relay
--

CREATE TABLE app.a (
    id integer NOT NULL,
    b_id integer
);


ALTER TABLE app.a OWNER TO relay;

--
-- Name: b; Type: TABLE; Schema: app; Owner: relay
--

CREATE TABLE app.b (
    id integer NOT NULL,
    a_id integer
);


ALTER TABLE app.b OWNER TO relay;

--
-- Name: base_log; Type: TABLE; Schema: app; Owner: relay
--

CREATE TABLE app.base_log (
    id integer,
    msg text,
    CONSTRAINT base_log_msg_check CHECK ((msg <> ''::text))
);


ALTER TABLE app.base_log OWNER TO relay;

--
-- Name: customers; Type: TABLE; Schema: app; Owner: relay
--

CREATE TABLE app.customers (
    id integer NOT NULL,
    email app.email,
    name text NOT NULL,
    nick public.citext,
    mood app.mood DEFAULT 'ok'::app.mood,
    created timestamp with time zone DEFAULT now() NOT NULL,
    ticket bigint DEFAULT app.next_ticket(),
    name_upper text GENERATED ALWAYS AS (upper(name)) STORED,
    CONSTRAINT name_not_blank CHECK ((name <> ''::text))
);


ALTER TABLE app.customers OWNER TO relay;

--
-- Name: TABLE customers; Type: COMMENT; Schema: app; Owner: relay
--

COMMENT ON TABLE app.customers IS 'People who buy things';


--
-- Name: COLUMN customers.email; Type: COMMENT; Schema: app; Owner: relay
--

COMMENT ON COLUMN app.customers.email IS 'Contact, unique';


--
-- Name: CONSTRAINT name_not_blank ON customers; Type: COMMENT; Schema: app; Owner: relay
--

COMMENT ON CONSTRAINT name_not_blank ON app.customers IS 'No empty names';


--
-- Name: big_order_customers; Type: VIEW; Schema: app; Owner: relay
--

CREATE VIEW app.big_order_customers AS
 SELECT c.name,
    o.total
   FROM (app.big_orders o
     JOIN app.customers c ON ((c.id = o.customer_id)));


ALTER VIEW app.big_order_customers OWNER TO relay;

--
-- Name: cache; Type: TABLE; Schema: app; Owner: plugboard_owner
--

CREATE UNLOGGED TABLE app.cache (
    k text NOT NULL,
    v text
)
WITH (fillfactor='70');


ALTER TABLE app.cache OWNER TO plugboard_owner;

--
-- Name: child_log; Type: TABLE; Schema: app; Owner: relay
--

CREATE TABLE app.child_log (
    level integer DEFAULT 1
)
INHERITS (app.base_log);


ALTER TABLE app.child_log OWNER TO relay;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: app; Owner: relay
--

ALTER TABLE app.customers ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME app.customers_id_seq
    START WITH 100
    INCREMENT BY 5
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: empty_mv; Type: MATERIALIZED VIEW; Schema: app; Owner: relay
--

CREATE MATERIALIZED VIEW app.empty_mv AS
 SELECT 1 AS x
  WITH NO DATA;


ALTER MATERIALIZED VIEW app.empty_mv OWNER TO relay;

--
-- Name: events; Type: TABLE; Schema: app; Owner: relay
--

CREATE TABLE app.events (
    id bigint NOT NULL,
    at date NOT NULL,
    kind text NOT NULL,
    payload bytea
)
PARTITION BY RANGE (at);


ALTER TABLE app.events OWNER TO relay;

--
-- Name: events_2025; Type: TABLE; Schema: app; Owner: relay
--

CREATE TABLE app.events_2025 (
    id bigint NOT NULL,
    at date NOT NULL,
    kind text NOT NULL,
    payload bytea
);


ALTER TABLE app.events_2025 OWNER TO relay;

--
-- Name: events_2026; Type: TABLE; Schema: app; Owner: relay
--

CREATE TABLE app.events_2026 (
    id bigint NOT NULL,
    at date NOT NULL,
    kind text NOT NULL,
    payload bytea
)
PARTITION BY LIST (kind);


ALTER TABLE app.events_2026 OWNER TO relay;

--
-- Name: events_2026_a; Type: TABLE; Schema: app; Owner: relay
--

CREATE TABLE app.events_2026_a (
    id bigint NOT NULL,
    at date NOT NULL,
    kind text NOT NULL,
    payload bytea
);


ALTER TABLE app.events_2026_a OWNER TO relay;

--
-- Name: events_2026_rest; Type: TABLE; Schema: app; Owner: relay
--

CREATE TABLE app.events_2026_rest (
    id bigint NOT NULL,
    at date NOT NULL,
    kind text NOT NULL,
    payload bytea
);


ALTER TABLE app.events_2026_rest OWNER TO relay;

--
-- Name: mood_counts; Type: MATERIALIZED VIEW; Schema: app; Owner: relay
--

CREATE MATERIALIZED VIEW app.mood_counts AS
 SELECT mood,
    count(*) AS n
   FROM app.customers
  GROUP BY mood
  WITH NO DATA;


ALTER MATERIALIZED VIEW app.mood_counts OWNER TO relay;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: app; Owner: relay
--

CREATE SEQUENCE app.orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE app.orders_id_seq OWNER TO relay;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: app; Owner: relay
--

ALTER SEQUENCE app.orders_id_seq OWNED BY app.orders.id;


--
-- Name: secure; Type: VIEW; Schema: app; Owner: plugboard_owner
--

CREATE VIEW app.secure WITH (security_barrier='true') AS
 SELECT id
   FROM app.customers;


ALTER VIEW app.secure OWNER TO plugboard_owner;

--
-- Name: ticket_seq; Type: SEQUENCE; Schema: app; Owner: relay
--

CREATE SEQUENCE app.ticket_seq
    START WITH 1000
    INCREMENT BY 7
    NO MINVALUE
    NO MAXVALUE
    CACHE 3;


ALTER SEQUENCE app.ticket_seq OWNER TO relay;

--
-- Name: SEQUENCE ticket_seq; Type: COMMENT; Schema: app; Owner: relay
--

COMMENT ON SEQUENCE app.ticket_seq IS 'Tickets';


--
-- Name: misc; Type: TABLE; Schema: public; Owner: relay
--

CREATE TABLE public.misc (
    id integer NOT NULL,
    f double precision,
    n numeric,
    b bytea,
    j json,
    x xml,
    i interval,
    u uuid,
    bits bit varying(8),
    arr integer[]
);


ALTER TABLE public.misc OWNER TO relay;

--
-- Name: events_2025; Type: TABLE ATTACH; Schema: app; Owner: relay
--

ALTER TABLE ONLY app.events ATTACH PARTITION app.events_2025 FOR VALUES FROM ('2025-01-01') TO ('2026-01-01');


--
-- Name: events_2026; Type: TABLE ATTACH; Schema: app; Owner: relay
--

ALTER TABLE ONLY app.events ATTACH PARTITION app.events_2026 FOR VALUES FROM ('2026-01-01') TO ('2027-01-01');


--
-- Name: events_2026_a; Type: TABLE ATTACH; Schema: app; Owner: relay
--

ALTER TABLE ONLY app.events_2026 ATTACH PARTITION app.events_2026_a FOR VALUES IN ('a');


--
-- Name: events_2026_rest; Type: TABLE ATTACH; Schema: app; Owner: relay
--

ALTER TABLE ONLY app.events_2026 ATTACH PARTITION app.events_2026_rest DEFAULT;


--
-- Name: orders id; Type: DEFAULT; Schema: app; Owner: relay
--

ALTER TABLE ONLY app.orders ALTER COLUMN id SET DEFAULT nextval('app.orders_id_seq'::regclass);


--
-- Data for Name: Mixed Case; Type: TABLE DATA; Schema: Odd Schema; Owner: relay
--

COPY "Odd Schema"."Mixed Case" ("Select", "a""b") FROM stdin;
\.
COPY "Odd Schema"."Mixed Case" ("Select", "a""b") FROM '$$PATH$$/3735.dat';

--
-- Data for Name: a; Type: TABLE DATA; Schema: app; Owner: relay
--

COPY app.a (id, b_id) FROM stdin;
\.
COPY app.a (id, b_id) FROM '$$PATH$$/3727.dat';

--
-- Data for Name: b; Type: TABLE DATA; Schema: app; Owner: relay
--

COPY app.b (id, a_id) FROM stdin;
\.
COPY app.b (id, a_id) FROM '$$PATH$$/3728.dat';

--
-- Data for Name: base_log; Type: TABLE DATA; Schema: app; Owner: relay
--

COPY app.base_log (id, msg) FROM stdin;
\.
COPY app.base_log (id, msg) FROM '$$PATH$$/3732.dat';

--
-- Data for Name: cache; Type: TABLE DATA; Schema: app; Owner: plugboard_owner
--

COPY app.cache (k, v) FROM stdin;
\.
COPY app.cache (k, v) FROM '$$PATH$$/3734.dat';

--
-- Data for Name: child_log; Type: TABLE DATA; Schema: app; Owner: relay
--

COPY app.child_log (id, msg, level) FROM stdin;
\.
COPY app.child_log (id, msg, level) FROM '$$PATH$$/3733.dat';

--
-- Data for Name: customers; Type: TABLE DATA; Schema: app; Owner: relay
--

COPY app.customers (id, email, name, nick, mood, created, ticket) FROM stdin;
\.
COPY app.customers (id, email, name, nick, mood, created, ticket) FROM '$$PATH$$/3724.dat';

--
-- Data for Name: events_2025; Type: TABLE DATA; Schema: app; Owner: relay
--

COPY app.events_2025 (id, at, kind, payload) FROM stdin;
\.
COPY app.events_2025 (id, at, kind, payload) FROM '$$PATH$$/3729.dat';

--
-- Data for Name: events_2026_a; Type: TABLE DATA; Schema: app; Owner: relay
--

COPY app.events_2026_a (id, at, kind, payload) FROM stdin;
\.
COPY app.events_2026_a (id, at, kind, payload) FROM '$$PATH$$/3730.dat';

--
-- Data for Name: events_2026_rest; Type: TABLE DATA; Schema: app; Owner: relay
--

COPY app.events_2026_rest (id, at, kind, payload) FROM stdin;
\.
COPY app.events_2026_rest (id, at, kind, payload) FROM '$$PATH$$/3731.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: app; Owner: relay
--

COPY app.orders (id, customer_id, total, items, tags, note, parent_id, pair, span, during) FROM stdin;
\.
COPY app.orders (id, customer_id, total, items, tags, note, parent_id, pair, span, during) FROM '$$PATH$$/3726.dat';

--
-- Data for Name: misc; Type: TABLE DATA; Schema: public; Owner: relay
--

COPY public.misc (id, f, n, b, j, x, i, u, bits, arr) FROM stdin;
\.
COPY public.misc (id, f, n, b, j, x, i, u, bits, arr) FROM '$$PATH$$/3736.dat';

--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: app; Owner: relay
--

SELECT pg_catalog.setval('app.customers_id_seq', 115, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: app; Owner: relay
--

SELECT pg_catalog.setval('app.orders_id_seq', 3, true);


--
-- Name: ticket_seq; Type: SEQUENCE SET; Schema: app; Owner: relay
--

SELECT pg_catalog.setval('app.ticket_seq', 1035, true);


--
-- Name: 424242; Type: BLOB METADATA; Schema: -; Owner: plugboard_owner
--

SELECT pg_catalog.lo_create('424242');

ALTER LARGE OBJECT 424242 OWNER TO plugboard_owner;

--
-- Name: LARGE OBJECT 424242; Type: COMMENT; Schema: -; Owner: plugboard_owner
--

COMMENT ON LARGE OBJECT 424242 IS 'a blob';


--
-- Name: 424243; Type: BLOB METADATA; Schema: -; Owner: relay
--

SELECT pg_catalog.lo_create('424243');

ALTER LARGE OBJECT 424243 OWNER TO relay;

--
-- Data for Name: 424242; Type: BLOBS; Schema: -; Owner: plugboard_owner
--

\i $$PATH$$/3742.dat

--
-- Data for Name: 424243; Type: BLOBS; Schema: -; Owner: relay
--

\i $$PATH$$/3740.dat

--
-- Name: a a_pkey; Type: CONSTRAINT; Schema: app; Owner: relay
--

ALTER TABLE ONLY app.a
    ADD CONSTRAINT a_pkey PRIMARY KEY (id);


--
-- Name: b b_pkey; Type: CONSTRAINT; Schema: app; Owner: relay
--

ALTER TABLE ONLY app.b
    ADD CONSTRAINT b_pkey PRIMARY KEY (id);


--
-- Name: cache cache_pkey; Type: CONSTRAINT; Schema: app; Owner: plugboard_owner
--

ALTER TABLE ONLY app.cache
    ADD CONSTRAINT cache_pkey PRIMARY KEY (k);


--
-- Name: customers customers_email_key; Type: CONSTRAINT; Schema: app; Owner: relay
--

ALTER TABLE ONLY app.customers
    ADD CONSTRAINT customers_email_key UNIQUE (email);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: app; Owner: relay
--

ALTER TABLE ONLY app.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: app; Owner: relay
--

ALTER TABLE ONLY app.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id, at, kind);


--
-- Name: events_2025 events_2025_pkey; Type: CONSTRAINT; Schema: app; Owner: relay
--

ALTER TABLE ONLY app.events_2025
    ADD CONSTRAINT events_2025_pkey PRIMARY KEY (id, at, kind);


--
-- Name: events_2026 events_2026_pkey; Type: CONSTRAINT; Schema: app; Owner: relay
--

ALTER TABLE ONLY app.events_2026
    ADD CONSTRAINT events_2026_pkey PRIMARY KEY (id, at, kind);


--
-- Name: events_2026_a events_2026_a_pkey; Type: CONSTRAINT; Schema: app; Owner: relay
--

ALTER TABLE ONLY app.events_2026_a
    ADD CONSTRAINT events_2026_a_pkey PRIMARY KEY (id, at, kind);


--
-- Name: events_2026_rest events_2026_rest_pkey; Type: CONSTRAINT; Schema: app; Owner: relay
--

ALTER TABLE ONLY app.events_2026_rest
    ADD CONSTRAINT events_2026_rest_pkey PRIMARY KEY (id, at, kind);


--
-- Name: orders note_short; Type: CHECK CONSTRAINT; Schema: app; Owner: relay
--

ALTER TABLE app.orders
    ADD CONSTRAINT note_short CHECK ((length(note) < 1000)) NOT VALID;


--
-- Name: orders orders_during_excl; Type: CONSTRAINT; Schema: app; Owner: relay
--

ALTER TABLE ONLY app.orders
    ADD CONSTRAINT orders_during_excl EXCLUDE USING gist (during WITH &&);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: app; Owner: relay
--

ALTER TABLE ONLY app.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: misc misc_pkey; Type: CONSTRAINT; Schema: public; Owner: relay
--

ALTER TABLE ONLY public.misc
    ADD CONSTRAINT misc_pkey PRIMARY KEY (id);


--
-- Name: events_kind; Type: INDEX; Schema: app; Owner: relay
--

CREATE INDEX events_kind ON ONLY app.events USING btree (kind);


--
-- Name: INDEX events_kind; Type: COMMENT; Schema: app; Owner: relay
--

COMMENT ON INDEX app.events_kind IS 'by kind';


--
-- Name: events_2025_kind_idx; Type: INDEX; Schema: app; Owner: relay
--

CREATE INDEX events_2025_kind_idx ON app.events_2025 USING btree (kind);


--
-- Name: events_2026_kind_idx; Type: INDEX; Schema: app; Owner: relay
--

CREATE INDEX events_2026_kind_idx ON ONLY app.events_2026 USING btree (kind);


--
-- Name: events_2026_a_kind_idx; Type: INDEX; Schema: app; Owner: relay
--

CREATE INDEX events_2026_a_kind_idx ON app.events_2026_a USING btree (kind);


--
-- Name: events_2026_rest_kind_idx; Type: INDEX; Schema: app; Owner: relay
--

CREATE INDEX events_2026_rest_kind_idx ON app.events_2026_rest USING btree (kind);


--
-- Name: mood_counts_mood_idx; Type: INDEX; Schema: app; Owner: relay
--

CREATE UNIQUE INDEX mood_counts_mood_idx ON app.mood_counts USING btree (mood);


--
-- Name: orders_note_lower; Type: INDEX; Schema: app; Owner: relay
--

CREATE INDEX orders_note_lower ON app.orders USING btree (lower(note)) WHERE (note IS NOT NULL);


--
-- Name: events_2025_kind_idx; Type: INDEX ATTACH; Schema: app; Owner: relay
--

ALTER INDEX app.events_kind ATTACH PARTITION app.events_2025_kind_idx;


--
-- Name: events_2025_pkey; Type: INDEX ATTACH; Schema: app; Owner: relay
--

ALTER INDEX app.events_pkey ATTACH PARTITION app.events_2025_pkey;


--
-- Name: events_2026_a_kind_idx; Type: INDEX ATTACH; Schema: app; Owner: relay
--

ALTER INDEX app.events_2026_kind_idx ATTACH PARTITION app.events_2026_a_kind_idx;


--
-- Name: events_2026_a_pkey; Type: INDEX ATTACH; Schema: app; Owner: relay
--

ALTER INDEX app.events_2026_pkey ATTACH PARTITION app.events_2026_a_pkey;


--
-- Name: events_2026_kind_idx; Type: INDEX ATTACH; Schema: app; Owner: relay
--

ALTER INDEX app.events_kind ATTACH PARTITION app.events_2026_kind_idx;


--
-- Name: events_2026_pkey; Type: INDEX ATTACH; Schema: app; Owner: relay
--

ALTER INDEX app.events_pkey ATTACH PARTITION app.events_2026_pkey;


--
-- Name: events_2026_rest_kind_idx; Type: INDEX ATTACH; Schema: app; Owner: relay
--

ALTER INDEX app.events_2026_kind_idx ATTACH PARTITION app.events_2026_rest_kind_idx;


--
-- Name: events_2026_rest_pkey; Type: INDEX ATTACH; Schema: app; Owner: relay
--

ALTER INDEX app.events_2026_pkey ATTACH PARTITION app.events_2026_rest_pkey;


--
-- Name: cache no_delete_pinned; Type: RULE; Schema: app; Owner: plugboard_owner
--

CREATE RULE no_delete_pinned AS
    ON DELETE TO app.cache
   WHERE (old.k = 'pinned'::text) DO INSTEAD NOTHING;


--
-- Name: RULE no_delete_pinned ON cache; Type: COMMENT; Schema: app; Owner: plugboard_owner
--

COMMENT ON RULE no_delete_pinned ON app.cache IS 'Keep pinned';


--
-- Name: orders orders_touch; Type: TRIGGER; Schema: app; Owner: relay
--

CREATE TRIGGER orders_touch BEFORE INSERT OR UPDATE ON app.orders FOR EACH ROW EXECUTE FUNCTION app.touch();


--
-- Name: TRIGGER orders_touch ON orders; Type: COMMENT; Schema: app; Owner: relay
--

COMMENT ON TRIGGER orders_touch ON app.orders IS 'it''s a trigger';


--
-- Name: a a_b_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: relay
--

ALTER TABLE ONLY app.a
    ADD CONSTRAINT a_b_id_fkey FOREIGN KEY (b_id) REFERENCES app.b(id);


--
-- Name: b b_a_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: relay
--

ALTER TABLE ONLY app.b
    ADD CONSTRAINT b_a_id_fkey FOREIGN KEY (a_id) REFERENCES app.a(id);


--
-- Name: orders orders_customer_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: relay
--

ALTER TABLE ONLY app.orders
    ADD CONSTRAINT orders_customer_id_fkey FOREIGN KEY (customer_id) REFERENCES app.customers(id) ON DELETE CASCADE;


--
-- Name: orders orders_parent_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: relay
--

ALTER TABLE ONLY app.orders
    ADD CONSTRAINT orders_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES app.orders(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: customers; Type: ROW SECURITY; Schema: app; Owner: relay
--

ALTER TABLE app.customers ENABLE ROW LEVEL SECURITY;

--
-- Name: customers own_rows; Type: POLICY; Schema: app; Owner: relay
--

CREATE POLICY own_rows ON app.customers FOR SELECT USING ((name <> 'hidden'::text));


--
-- Name: POLICY own_rows ON customers; Type: COMMENT; Schema: app; Owner: relay
--

COMMENT ON POLICY own_rows ON app.customers IS 'Hide hidden';


--
-- Name: SCHEMA app; Type: ACL; Schema: -; Owner: relay
--

GRANT USAGE ON SCHEMA app TO plugboard_reader;


--
-- Name: TYPE pair; Type: ACL; Schema: app; Owner: relay
--

REVOKE ALL ON TYPE app.pair FROM PUBLIC;


--
-- Name: TABLE orders; Type: ACL; Schema: app; Owner: relay
--

GRANT SELECT ON TABLE app.orders TO plugboard_reader;
GRANT INSERT ON TABLE app.orders TO plugboard_reader WITH GRANT OPTION;


--
-- Name: TABLE big_orders; Type: ACL; Schema: app; Owner: relay
--

GRANT SELECT ON TABLE app.big_orders TO plugboard_reader;


--
-- Name: FUNCTION next_ticket(); Type: ACL; Schema: app; Owner: relay
--

REVOKE ALL ON FUNCTION app.next_ticket() FROM PUBLIC;
GRANT ALL ON FUNCTION app.next_ticket() TO plugboard_reader;


--
-- Name: TABLE a; Type: ACL; Schema: app; Owner: relay
--

GRANT SELECT ON TABLE app.a TO plugboard_reader;


--
-- Name: TABLE b; Type: ACL; Schema: app; Owner: relay
--

GRANT SELECT ON TABLE app.b TO plugboard_reader;


--
-- Name: TABLE base_log; Type: ACL; Schema: app; Owner: relay
--

GRANT SELECT ON TABLE app.base_log TO plugboard_reader;


--
-- Name: TABLE customers; Type: ACL; Schema: app; Owner: relay
--

GRANT SELECT ON TABLE app.customers TO plugboard_reader;


--
-- Name: COLUMN customers.id; Type: ACL; Schema: app; Owner: relay
--

GRANT SELECT(id) ON TABLE app.customers TO plugboard_reader;


--
-- Name: COLUMN customers.name; Type: ACL; Schema: app; Owner: relay
--

GRANT SELECT(name),UPDATE(name) ON TABLE app.customers TO plugboard_reader;


--
-- Name: TABLE big_order_customers; Type: ACL; Schema: app; Owner: relay
--

GRANT SELECT ON TABLE app.big_order_customers TO plugboard_reader;


--
-- Name: TABLE cache; Type: ACL; Schema: app; Owner: plugboard_owner
--

GRANT SELECT ON TABLE app.cache TO plugboard_reader;


--
-- Name: TABLE child_log; Type: ACL; Schema: app; Owner: relay
--

GRANT SELECT ON TABLE app.child_log TO plugboard_reader;


--
-- Name: TABLE empty_mv; Type: ACL; Schema: app; Owner: relay
--

GRANT SELECT ON TABLE app.empty_mv TO plugboard_reader;


--
-- Name: TABLE events; Type: ACL; Schema: app; Owner: relay
--

GRANT SELECT ON TABLE app.events TO plugboard_reader;


--
-- Name: TABLE events_2025; Type: ACL; Schema: app; Owner: relay
--

GRANT SELECT ON TABLE app.events_2025 TO plugboard_reader;


--
-- Name: TABLE events_2026; Type: ACL; Schema: app; Owner: relay
--

GRANT SELECT ON TABLE app.events_2026 TO plugboard_reader;


--
-- Name: TABLE events_2026_a; Type: ACL; Schema: app; Owner: relay
--

GRANT SELECT ON TABLE app.events_2026_a TO plugboard_reader;


--
-- Name: TABLE events_2026_rest; Type: ACL; Schema: app; Owner: relay
--

GRANT SELECT ON TABLE app.events_2026_rest TO plugboard_reader;


--
-- Name: TABLE mood_counts; Type: ACL; Schema: app; Owner: relay
--

GRANT SELECT ON TABLE app.mood_counts TO plugboard_reader;


--
-- Name: TABLE secure; Type: ACL; Schema: app; Owner: plugboard_owner
--

GRANT SELECT ON TABLE app.secure TO plugboard_reader;


--
-- Name: SEQUENCE ticket_seq; Type: ACL; Schema: app; Owner: relay
--

GRANT USAGE ON SEQUENCE app.ticket_seq TO plugboard_reader;


--
-- Name: LARGE OBJECT 424243; Type: ACL; Schema: -; Owner: relay
--

GRANT SELECT ON LARGE OBJECT 424243 TO plugboard_reader;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: app; Owner: relay
--

ALTER DEFAULT PRIVILEGES FOR ROLE relay IN SCHEMA app GRANT SELECT ON TABLES TO plugboard_reader;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: -; Owner: relay
--

ALTER DEFAULT PRIVILEGES FOR ROLE relay REVOKE ALL ON FUNCTIONS FROM PUBLIC;


--
-- Name: mood_counts; Type: MATERIALIZED VIEW DATA; Schema: app; Owner: relay
--

REFRESH MATERIALIZED VIEW app.mood_counts;


--
-- PostgreSQL database dump complete
--

